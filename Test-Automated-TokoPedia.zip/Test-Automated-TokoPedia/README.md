# Test-Automated-TokoPedia
This is my assignment &amp; portfolio to improve my skills in Automation test.
